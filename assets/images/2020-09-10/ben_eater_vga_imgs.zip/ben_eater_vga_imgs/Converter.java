
import java.awt.Component;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Converter extends Component {
	public static void main(String[] args) {
		if (args.length != 2) {
			System.err.println("use program input_picture.png output_file.bin");
			System.exit(1);
		}
		
		String inputFile = args[0];
		String outputFile = args[1];
		
		try {
			// get the BufferedImage, using the ImageIO class
			BufferedImage image =
					ImageIO.read(new FileInputStream(inputFile));

			FileOutputStream output = new FileOutputStream(outputFile, false);

			int w = image.getWidth();
			int h = image.getHeight();
			System.out.println("recognized picture width, height: " + w + ", " + h);

			if (w != 100 || h != 75) {
				System.err.println("invalid picture size, use 100px x 75px PNG image!");
				System.exit(1);
			}

			byte[] pixels = ((DataBufferByte)image.getRaster().getDataBuffer()).getData() ;

			for (int i = 0; i < 256; i++) {
				for (int j = 0; j < 128; j++) {
					int index = (i >= h || j >= w) ? 0 : pixels[i*w + j];
					output.write(index);
				}
			}

			output.close();
			System.out.println("DONE.");

		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}
}



