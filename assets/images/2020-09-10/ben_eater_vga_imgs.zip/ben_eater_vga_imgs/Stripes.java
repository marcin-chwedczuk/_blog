
import java.awt.Component;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Stripes extends Component {
	public static void main(String[] args) {
		if (args.length != 2) {
			System.err.println("use program output_file.bin [pallete|chess|rows|cols]");
			System.exit(1);
		}
		
		String outputFile = args[0];
		String mode = args[1];
		
		switch(mode) {
		        case "pallete": case "chess": case "rows": case "cols": break;
		        default: 
		                System.err.println("Invalid mode: " + mode);
		                System.exit(1);
		}
		
		try {
			FileOutputStream output = new FileOutputStream(outputFile, false);

			int w = 100;
			int h = 75;
			
			for (int i = 0; i < 256; i++) {
				for (int j = 0; j < 128; j++) {
				        int v = 0;
				        switch (mode) {
				        case "pallete": v = (i + j) % 64; break;
				        case "chess": v = (i + j) % 2 == 0 ? 0 : 63; break;
				        case "rows": v = i % 2 == 0 ? 0 : 63; break;
				        case "cols": v = j % 2 == 0 ? 0 : 63; break;
				        }
				
					int index = (i >= h || j >= w) ? 0 : v;
					output.write(index);
				}
			}

			output.close();
			System.out.println("DONE.");

		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}
}



