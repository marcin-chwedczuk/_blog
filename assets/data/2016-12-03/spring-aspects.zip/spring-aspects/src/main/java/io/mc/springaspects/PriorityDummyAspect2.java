package io.mc.springaspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

// @Aspect
@Component
@Order(1000)
public class PriorityDummyAspect2 {
    private ConsoleLogger consoleLogger;
    
    @Autowired
    public PriorityDummyAspect2(ConsoleLogger consoleLogger) {
        this.consoleLogger = consoleLogger;
    }

    @Pointcut("execution(* io.mc.springaspects.DummyComponent.doStuff())")
    protected void doStuff() { }
    
    @Before("doStuff()")
    public void beforeDoStuff(JoinPoint joinPoint) {
        consoleLogger.log("PRIORITY DUMMY ASPECT - BEFORE doStuff()");
    }
}
