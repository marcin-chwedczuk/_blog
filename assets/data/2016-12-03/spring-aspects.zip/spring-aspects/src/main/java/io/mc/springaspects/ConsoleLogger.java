package io.mc.springaspects;

import org.springframework.stereotype.Component;

@Component
public class ConsoleLogger {
    public void log(String message, Object... args) {
        System.out.printf(message, args);
        System.out.println();
    }
}
