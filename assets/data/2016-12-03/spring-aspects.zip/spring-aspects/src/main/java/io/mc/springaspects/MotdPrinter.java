package io.mc.springaspects;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;

@Service
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class MotdPrinter {
    private final String motd;

    public MotdPrinter(String motd) {
        super();
        this.motd = motd;
    }
    
    public void printMotd() {
        String prefix = "* ";
        String suffix = " *";
        
        String bar = Strings.repeat("*",
                prefix.length() + motd.length() + suffix.length());
        
        System.out.println(bar);
        System.out.println(prefix + motd + suffix);
        System.out.println(bar);
    }
}
