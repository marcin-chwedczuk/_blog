package io.mc.springaspects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("implB")
public class DummyInterfaceImplB implements DummyInterface {

    private final ConsoleLogger logger;
    
    @Autowired
    public DummyInterfaceImplB(ConsoleLogger logger) {
        this.logger = logger;
    }

    @Override
    public void dummyMethod() {
        logger.log("DummyInterface Implementation B");
    }
}
