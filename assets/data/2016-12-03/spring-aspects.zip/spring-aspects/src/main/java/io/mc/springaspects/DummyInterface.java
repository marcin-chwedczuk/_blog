package io.mc.springaspects;

public interface DummyInterface {
    void dummyMethod();
}
