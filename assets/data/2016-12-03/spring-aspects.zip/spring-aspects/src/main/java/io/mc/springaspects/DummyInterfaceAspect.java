package io.mc.springaspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class DummyInterfaceAspect {
    private final ConsoleLogger logger;
    
    public DummyInterfaceAspect(ConsoleLogger logger) {
        this.logger = logger;
    }

    @Pointcut("execution(void io.mc.springaspects.DummyInterface+.*(..))")
    protected void dummyMethod() { }
    
    @Before("dummyMethod()")
    public void beforeDummyMethod(JoinPoint joinPoint) {
        String implementation =
                joinPoint.getTarget().getClass().getSimpleName();
        
        logger.log("X Interface method called from class: %s", implementation);
    }
}
