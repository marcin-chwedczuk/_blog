package io.mc.springaspects;

import java.util.Collection;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Order(100)
public class DummyAspect {
    private final ConsoleLogger consoleLogger;

    @Autowired
    public DummyAspect(ConsoleLogger consoleLogger) {
        this.consoleLogger = consoleLogger;
    }
    
    @Pointcut("execution(@io.mc.springaspects.UseAdviceOnThisMethod * *.*(..))")
    protected void useAdviceOnThisMethodAnnotation() { }    
    
    @Before("useAdviceOnThisMethodAnnotation() && @annotation(useAdvice)")
    public void useAdviceBefore(JoinPoint joinPoint, UseAdviceOnThisMethod useAdvice) {
        consoleLogger.log("VALUE: %s", useAdvice.value());
    }
    
    
    @Pointcut("execution(* io.mc.springaspects.DummyComponent.getNumbers(int))")
    protected void getNumbers() { }
    
    @AfterReturning(pointcut="getNumbers()", returning="result")
    public void aroundGetNumbers(Collection<Integer> result) throws Throwable {
        if (result != null)
            result.add(111);
    }
    
    
    @Pointcut("execution(* io.mc.springaspects.DummyComponent.greetUser(String))")
    protected void greetUser() { }
    
    @Around("greetUser()")
    public void beforeGreetUser(ProceedingJoinPoint joinPoint) throws Throwable {
        Object[] originalArguments = joinPoint.getArgs();
        
        Object[] newArguments = new Object[1];
        newArguments[0] = ((String)originalArguments[0]).toUpperCase();
        
        // joinPoint.proceed(newArguments);
    }
    
    
    @Pointcut("execution(* io.mc.springaspects.DummyComponent.doStuff())")
    protected void doStuff() { }

    @Pointcut("execution(void io.mc.springaspects.DummyComponent.doStuff(String,String)) && args(arg1,arg2)")
    protected void doStuff2(String arg1, String arg2) { }
    
    @Before("doStuff2(arg1, arg2)")
    public void beforeDoStuff(String arg1, String arg2) {
        consoleLogger.log("arg1 = %s, jarg2 = %s", arg1, arg2);
        // consoleLogger.log("$$$$$$$$$$$$$$$$$$$$");
        /*consoleLogger.log("BEFORE CALL TO doStuff()");
        
        consoleLogger.log("ARGUMENTS:");
        Arrays.stream(joinPoint.getArgs())
            .map(Object::toString)
            .forEach(arg -> consoleLogger.log("\t%s", arg));
        
        consoleLogger.log("");*/
    }


    
    // @Before("doStuffX(x)")
    public void beforeDoStuffX(JoinPoint joinPoint, String x) {
        consoleLogger.log("BEFORE CALL TO doStuff(x)");
        consoleLogger.log("ARGUMENT x = %s", x);
        consoleLogger.log("");
    }
    
    // @After("doStuff()")
    public void afterDoStuff() {
        consoleLogger.log("AFTER CALL TO doStuff()");
        consoleLogger.log("");
    }
    
    @Pointcut("execution(* io.mc.springaspects.DummyComponent.doThrow())")
    protected void doThrow() { }
    
    @AfterThrowing(pointcut="doThrow()", throwing="ex")
    public void doThrowThrows(TestException ex) {
        consoleLogger.log("doThrow() THROWS EXCEPTION: %s", ex.getClass().getSimpleName());
    }
}
