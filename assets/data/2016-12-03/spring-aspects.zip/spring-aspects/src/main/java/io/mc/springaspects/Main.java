package io.mc.springaspects;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String... args) throws Exception {
        
        AnnotationConfigApplicationContext appContext = 
                new AnnotationConfigApplicationContext(SpringConfiguration.class);
        
        DummyComponent dummyComponent = appContext.getBean(DummyComponent.class);
        dummyComponent.someMethod();
        
        //dummyComponent = (DummyComponent) 
        //       ((Advised)dummyComponent).getTargetSource().getTarget();
        
        //System.out.println(dummyComponent.getNumbers(0));
        //System.out.println(dummyComponent.getNumbers(7));
        
        // dummyComponent.doStuff("foo");
        
        /*try {
            dummyComponent.doThrow();
        }
        catch(Exception e) {
            System.out.println("AFTER CATCH:");
            e.printStackTrace();
        }*/
        
        //DummyInterface dummyInterface = (DummyInterface) appContext.getBean("implB");
        //dummyInterface.dummyMethod();
        
        /*
        Greeter greeter = 
                appContext.getBean(Greeter.class);
        
        String result = greeter.greetUser("mc");
        System.out.printf("RETURN (MAIN): %s%n", result);
        
        MotdPrinter motdPrinter = appContext.getBean(MotdPrinter.class, "anya nyaa!");
        motdPrinter.printMotd();
        */
        
        appContext.close();
    }
}
