package io.mc.springaspects;

import static java.util.stream.Collectors.toList;

import java.util.Collection;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DummyComponent {
    private final ConsoleLogger consoleLogger;
    
    @UseAdviceOnThisMethod("foo")
    public void someMethod() {
        consoleLogger.log("Hello, world!");
    }
    
    @Autowired
    public DummyComponent(ConsoleLogger consoleLogger) {
        this.consoleLogger = consoleLogger;
    }

    public void doStuff() {
        consoleLogger.log("TestComponent::doStuff");
    }
    
    public void doStuff(String x, String y) {
        consoleLogger.log("TestComponent::doStuff(x, y), x = %s, y = %s", x, y);
    }
    
    public void greetUser(String userName) {
        consoleLogger.log("Hello, %s", userName);
    }
    
    public Collection<Integer> getNumbers(int  size) {
        if (size == 0)
            return null;
     
        return IntStream.range(0, size)
            .mapToObj(Integer::valueOf)
            .collect(toList());
    }
    
    public void doThrow() {
        throw new TestException("TestException from TestComponent::doThrow");
    }
}
