package io.mc.springaspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

// @Aspect
@Component
public class PriorityDummyAspect {
    private ConsoleLogger consoleLogger;
    
    @Autowired
    public PriorityDummyAspect(ConsoleLogger consoleLogger) {
        this.consoleLogger = consoleLogger;
    }

    @Pointcut("execution(* io.mc.springaspects.DummyComponent.doStuff())")
    protected void doStuff() { }
    
    @Before("doStuff()")
    public void beforeDoStuff(JoinPoint joinPoint) {
        consoleLogger.log("PRIORITY DUMMY ASPECT 222 - BEFORE doStuff()");
    }
}
