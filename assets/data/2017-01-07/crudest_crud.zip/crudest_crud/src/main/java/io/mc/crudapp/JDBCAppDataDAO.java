package io.mc.crudapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceUtils;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class JDBCAppDataDAO implements AppDataDAO {
    private DataSource ds;

    @Autowired
    public JDBCAppDataDAO(DataSource ds) {
        this.ds = Objects.requireNonNull(ds);
    }

    private interface ConnectionConsumer<T> {
        T consume(Connection conn) throws SQLException;
    }

    private <T> T usingConnection(ConnectionConsumer<T> consumer) {
        Connection connection = DataSourceUtils.getConnection(ds);

        try {
            return consumer.consume(connection);
        }
        catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        finally {
            DataSourceUtils.releaseConnection(connection, ds);
        }
    }

    @Override
    public int insert(int index, String value) {
        return usingConnection(conn -> {
            String sql = "insert into app_data(index,value) values(?,?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, index);
                stmt.setString(2, value);

                stmt.executeUpdate();

                try(ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        return rs.getInt(1);
                    }
                    else throw new RuntimeException("no generated key!");
                }
            }
        });
    }

    @Override
    public void update(int id, int newIndex, String newValue) {
        usingConnection(conn -> {
            String sql = "update app_data set index=?, value=? where id=?";
            try(PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, newIndex);
                stmt.setString(2, newValue);
                stmt.setInt(3, id);

                stmt.executeUpdate();
            }

            return null;
        });
    }

    @Override
    public boolean delete(int id) {
        return usingConnection(conn -> {
            String sql = "delete from app_data where id=?";
            try(PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, id);
                int rowsAffected = stmt.executeUpdate();
                return (rowsAffected > 0);
            }
        });
    }

    @Override
    public List<AppData> selectAll() {
        return usingConnection(conn -> {
            String sql = "select id,index,value from app_data";
            try(PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

                List<AppData> queryResult = new ArrayList<>();

                while (rs.next()) {
                    int id = rs.getInt("id");
                    int index = rs.getInt("index");
                    String value = rs.getString("value");

                    queryResult.add(new AppData(id, index, value));
                }

                return queryResult;
            }
        });
    }
}
