package io.mc.crudapp;

public class AppData {
    private final int id;
    private final int index;
    private final String value;

    public AppData(int id, int index, String value) {
        this.id = id;
        this.index = index;
        this.value = value;
    }

    public int getId() {
        return id;
    }

    public int getIndex() {
        return index;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return "AppData{" +
                "id=" + id +
                ", index=" + index +
                ", value='" + value + '\'' +
                '}';
    }
}
