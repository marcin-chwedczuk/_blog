package io.mc.crudapp;

import java.util.List;

public interface AppDataDAO {
    int insert(int index, String value);
    void update(int id, int newIndex, String newValue);
    boolean delete(int id);
    List<AppData> selectAll();
}
