package io.mc.crudapp;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.sql.DataSource;
import java.sql.*;



public class Main {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext appContext =
                new ClassPathXmlApplicationContext(new String[] {
                        "spring/app-context.xml"
                });

        CRUDAppDemoService service = appContext.getBean(CRUDAppDemoService.class);
        service.doDemo();

        appContext.close();
    }

}
