package io.mc.crudapp;

public interface CRUDAppDemoService {
    void doDemo();
}
