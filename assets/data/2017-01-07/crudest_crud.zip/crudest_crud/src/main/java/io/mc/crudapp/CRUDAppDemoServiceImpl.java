package io.mc.crudapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;

public class CRUDAppDemoServiceImpl implements CRUDAppDemoService {
    private final AppDataDAO appDataDAO;

    @Autowired
    public CRUDAppDemoServiceImpl(AppDataDAO appDataDAO) {
        this.appDataDAO = Objects.requireNonNull(appDataDAO);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public void doDemo() {
        appDataDAO.insert(101, "foo");
        someOperation();
        appDataDAO.insert(102, "bar");
    }

    private static void someOperation() {
        throw new RuntimeException("uber error");
    }
}

